# Session Learning Changelog - 2026-04-28

Audience: Suvrat, as the product owner learning to reason more deeply about the Catch Flutter/Firebase codebase.

Scope: Full app audit, Firebase setup, safety/blocking/account deletion implementation, platform build checks, run sharing/bookmarking, run-club rules hardening, and rules emulator coverage.

## Executive Summary

The Catch app is much closer to launch readiness, but it is not fully feature complete. The core mobile app now has stronger backend safety boundaries, deployed Firebase infrastructure, App Check client initialization, run/run-club sharing, saved runs, and Firestore rules tests. The highest remaining risks are live smoke testing, App Check web/debug-token/enforcement setup, Android release signing fingerprints, iOS/macOS local build repair, moderation tooling for user reports, and several product surfaces from the design handoff.

The most important engineering theme from this session was moving trust out of the Flutter client and into server-owned layers:

- Firestore Security Rules decide who can directly read/write documents.
- Cloud Functions perform privileged workflows such as payment verification, booking, blocking, reporting, and account deletion.
- Firebase console settings and secrets determine whether deployed code can actually run.
- Tests and emulator coverage prove the security rules before the app reaches users.

## What Changed

### Audit and Tracking

Created and updated durable audit docs under `codex_audit/`:

- `full_app_audit_tracker.md`
- `lib_feature_completeness_matrix.md`
- `firebase_console_audit.md`
- `safety_blocking_account_deletion_plan.md`
- this file, `session_learning_changelog_2026-04-28.md`

These files are the handoff state for future sessions. They track commands, pass/fail results, completed gaps, and remaining product/backend risks.

### Firebase Region and Deployment

The Firebase project `catch-dating-app-64e51` was configured for an India-first backend:

- Default Firestore database created in `asia-south1` (Mumbai).
- Cloud Functions deployed in `asia-south1`.
- Hosting rewrite for `/api/join-waitlist` points to the `asia-south1` Function.
- Firestore rules, Firestore indexes, and Storage rules deployed.
- All 17 expected Functions verified live by `firebase functions:list`.
- Artifact Registry cleanup policy configured for old Function container images.

Why this matters:

- Region affects latency and cost.
- Firestore location is effectively a long-term project decision.
- Functions near Firestore reduce cross-region latency and avoid avoidable cross-region behavior.

### Razorpay and Secret Manager

Razorpay credentials were uploaded to Firebase Secret Manager:

- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`

The values were staged without printing them in terminal output and temporary local secret files were removed afterward.

Why this matters:

- Payment secrets must never live in Flutter client code.
- Cloud Functions can read secrets at runtime.
- Firebase secrets are bound only to Functions that need them.

### Blocking, Reporting, and Account Deletion

Implemented the first production safety slice:

- Top-level `blocks` model and bidirectional block checks.
- `blockUser` and `unblockUser` callable Functions.
- Block-aware run sign-up, Razorpay order creation, waitlist promotion, swipe matching, match/chat visibility, profile reads, and public-profile reads.
- Settings/Safety UI, blocked-account management, chat block actions, and public-profile report/block actions.
- `requestAccountDeletion` callable Function.
- Deleted-user tombstone model.
- Account deletion UI.
- Storage cleanup for standard Firebase Storage profile photo download URLs.
- `reportUser` callable Function and server-owned `reports` documents.
- Rules deny client reads/writes to `reports` and `deletedUsers`.

Why this matters:

- A dating app has a higher safety bar than a typical social app.
- The client can hide buttons, but the server must enforce the real safety boundary.
- Blocking needs to affect more than chat: bookings, swipes, matches, rosters, profiles, and future recommendations all need to respect it.

### Firestore Rules Hardening

Firestore rules now include:

- block/deleted-user privacy restrictions
- server-owned `reports`
- server-owned `deletedUsers`
- block-aware profile/public-profile reads
- blocked-match hiding
- chat message denial on blocked matches
- corrected `runClubs` validation for the current Dart model

The `runClubs` rules were specifically fixed to match the app's real model fields:

- `area`
- `hostName`
- `hostAvatarUrl`
- `tags`
- `memberCount`
- `rating`
- `reviewCount`
- `nextRunAt`
- `nextRunLabel`

The rules now allow join/leave updates to change both `memberUserIds` and `memberCount`, while requiring `memberCount == memberUserIds.size()`.

Why this matters:

- Before this fix, valid app writes could fail in production because the rules expected an older data shape.
- Security rules are not just permissions; they are schema validation for client writes.

### Firestore Rules Emulator Tests

Added a dedicated rules test harness:

- `functions/test/firestore.rules.test.cjs`
- `functions/package.json` script: `npm --prefix functions run test:rules`
- dependency: `@firebase/rules-unit-testing`

Covered paths:

- current `runClubs` create schema succeeds
- legacy/incomplete `runClubs` schema fails
- join with correct `memberCount` succeeds
- member tampering with host/profile fields fails
- stale `memberCount` fails
- profile reads fail after block
- profile reads fail after deletion
- block reads are visible only to involved users
- reports and deletion tombstones are server-owned
- blocked matches are hidden

Why this matters:

- The emulator tests security behavior without touching production data.
- They let us prove sensitive behavior before enabling or deploying stricter policies.

### App Check

Added and initialized `firebase_app_check` in Flutter.

Firebase console state:

- iOS App Check registered with App Attest.
- Android App Check registered with Play Integrity.
- Android debug SHA-1 and SHA-256 fingerprints registered.
- Enforcement is still off intentionally.
- Web App Check is not complete yet.

Why this matters:

App Check is Firebase's app attestation layer. It helps Firebase reject requests that do not come from an authorized, genuine app. It is not a replacement for Auth or Security Rules:

- Auth answers: who is the user?
- Security Rules answer: is this user allowed to read/write this document?
- App Check answers: did this request come from an app/client we trust?

Do not enforce App Check until real devices, debug workflows, web provider setup, and live smoke tests are ready. Enforcement too early can lock out legitimate development builds.

### Android SHA Fingerprints

Registered local Android debug SHA-1 and SHA-256 fingerprints.

Why this matters:

Android apps are signed. Firebase uses SHA fingerprints to associate a signed Android app with the Firebase project. Debug and release builds use different certificates, so release fingerprints still need to be added later.

This matters for:

- Phone Auth
- Google Sign-In if added later
- App Check Play Integrity
- any Firebase service that validates Android app identity

### Run Sharing and Saved Runs

Implemented previously unfinished product affordances:

- Run detail share uses `share_plus` and route-backed `catchdates.com` links.
- Run club share uses `share_plus` and route-backed `catchdates.com` links.
- Run detail bookmark persists to `users/{uid}.savedRunIds`.
- Widget tests cover share handler and saved/unsaved behavior.

Why this matters:

- The previous UI had buttons that looked functional but were placeholders.
- Persisting saved runs in Firestore means saved state follows the user across devices.
- A follow-up product surface is still needed if saved runs should be browsable from a list.

### Flutter Test and Build Hardening

Major verification results:

- `flutter analyze` passed after fixes.
- Full Flutter test suite passed, now 361 tests.
- Web build passed.
- Android APK build passed.
- Functions lint/build/tests passed.
- Firestore rules emulator tests passed.

Test infrastructure improvements:

- Map widget tests no longer hit live OpenStreetMap tiles.
- Router widget tests were narrowed to route contracts where full auth-gated shell boot was brittle.
- Existing tile 400 noise was removed by adding a test seam for map tile loading.

### iOS and macOS Build State

macOS build remains blocked by signing/entitlements.

iOS build remains blocked by Xcode destination discovery. The simulator exists and `xcodebuild -showsdks` lists iOS 26.4, but the Runner scheme reports no eligible destination and claims the platform is unavailable. I added simulator support metadata to the iOS project, but the local Xcode toolchain still does not expose an eligible destination.

Why this matters:

- Flutter depends on Xcode for iOS/macOS compilation.
- iOS/macOS builds are not just Dart compilation; they require Apple platform project configuration, signing, entitlements, schemes, SDKs, and simulator/device destinations.
- This is an environment/toolchain issue to isolate separately from app logic.

## Current Feature Completeness

Conservative status from `lib_feature_completeness_matrix.md`:

- Auth: partial
- Onboarding: mostly built
- Dashboard: partial
- Run clubs: mostly built
- Runs: partial
- Calendar: missing
- Catches/swipes: partial
- Matches/chats: mostly built
- Profile: partial
- Payments: mostly built
- Force update: built
- Image uploads: built
- Reviews: built
- Public profile: built
- Core/theme/widgets: mostly built
- Routing: partial

The app is not fully feature complete. It is much stronger on backend safety and core flows than it was at the start of this audit, but launch readiness still depends on smoke tests, release credentials, App Check enforcement preparation, moderation tooling, and remaining product surfaces.

## Remaining High-Priority Work

1. Resolve the Google Cloud account verification warning.
2. Add Android release SHA-1/SHA-256 fingerprints once release signing is finalized.
3. Finish App Check web provider/debug-token setup, then enforce only after smoke tests pass.
4. Run live backend smoke tests for booking, payment, block, report, delete, and run-club create/join/leave flows.
5. Repair iOS Xcode destination discovery and macOS signing.
6. Add moderation/admin review workflow for `reports`.
7. Add calendar/timeline and host manage routes if still launch scope.
8. Add saved-runs discovery/list surfaces if saved runs are intended as a real product feature.

## Concepts To Understand

### Firebase App Check

App Check is a gate in front of Firebase resources. It checks whether a request appears to come from a legitimate app instance. On Android, the provider is commonly Play Integrity. On Apple platforms, App Attest or DeviceCheck are used. On web, Firebase commonly uses reCAPTCHA Enterprise or reCAPTCHA v3.

App Check does not replace authentication. A malicious but signed-in user is still signed in. App Check is about app/client legitimacy, not user authorization.

Mental model:

```text
Auth: "Who is this user?"
Rules: "Can this user perform this read/write?"
App Check: "Is this request coming from a legitimate app/client?"
Functions: "Run privileged backend logic safely."
```

### SHA Fingerprints

A SHA fingerprint is a cryptographic hash of an Android signing certificate. Firebase uses it to recognize the signed Android app. Debug builds and release builds are signed with different certificates, so both debug and release fingerprints matter.

Debug fingerprints help local development. Release fingerprints are required before production distribution.

### Secret Manager

Secret Manager stores sensitive values like Razorpay credentials outside the codebase. Cloud Functions can be granted access to specific secrets. The Flutter app should never contain payment secrets because a mobile app can be reverse engineered.

### Firestore Security Rules

Rules are the authorization and validation layer for direct client access to Firestore. They run on Firebase servers. They should be treated as part of the backend, not as documentation.

Examples from this session:

- Users cannot directly read profiles when a block exists.
- Clients cannot write reports.
- Clients cannot write deletion tombstones.
- Run-club join writes must keep `memberCount` aligned with `memberUserIds`.

### Cloud Functions

Cloud Functions are trusted backend code. They can use the Admin SDK, read secrets, perform transactions, and enforce workflows that are too sensitive for the client.

In this app, Functions are critical for:

- Razorpay order creation and verification
- run booking and cancellation
- waitlist promotion
- block/unblock workflows
- reporting
- account deletion
- public profile sync
- matching/chat notification triggers

### Firestore Data Modeling

This app uses a mix of source documents and projections.

Examples:

- `users/{uid}` is the private user profile.
- `publicProfiles/{uid}` is a backend-owned projection for public/social surfaces.
- `blocks/{blockerUid__blockedUid}` is a deterministic edge document.
- `deletedUsers/{uid}` is a tombstone that lets rules/functions know an account is gone without retaining profile data.
- `reports/{reportId}` is server-owned moderation data.

The key idea is ownership: if a client should not be trusted to set a field, that field should be owned by Functions or constrained tightly by rules.

### Denormalization

Denormalization means storing derived or duplicated data to make reads fast or simple. `memberCount` on a run club duplicates the length of `memberUserIds`. That is useful for UI and queries, but it creates a consistency risk. The rules fix enforces that the count matches the list size on client writes.

### Riverpod

Riverpod is the app's state-management and dependency-injection system. Providers expose repositories, streams, controllers, and derived UI state. The benefit is testability: tests can override providers with fake repositories.

Example from this session:

- `userProfileRepositoryProvider` was overridden in widget tests to verify saved-run behavior without touching Firestore.

### Freezed and build_runner

Freezed generates immutable model helpers such as equality, `copyWith`, and JSON serialization support. `build_runner` regenerates the generated `.freezed.dart`, `.g.dart`, and provider files after model/provider changes.

Example:

- Adding `savedRunIds` to `UserProfile` required running `dart run build_runner build --delete-conflicting-outputs`.

### share_plus

`share_plus` opens the native platform share sheet. On Android it wraps the platform share intent; on iOS it uses the iOS share controller. In this app it powers run and run-club sharing.

### Firebase Rules Unit Testing

`@firebase/rules-unit-testing` lets tests create fake authenticated users and assert whether reads/writes succeed or fail against local Firestore emulator rules. This is the right tool for rules because normal server SDKs bypass Firestore Security Rules.

### iOS/macOS Signing and Entitlements

Apple platforms require signing. Signing proves who built the app and what capabilities it is allowed to use. Entitlements are permissions such as App Sandbox, push notifications, associated domains, or App Attest.

A Flutter iOS/macOS build therefore depends on:

- Flutter/Dart compilation
- CocoaPods/native dependencies
- Xcode project settings
- a valid Apple developer team/certificate/profile
- supported SDK and simulator/device destination
- correct entitlements

### Android Signing

Android release apps must be signed. For Play Store release, there is usually an upload key and a Play app-signing key. Firebase release SHA fingerprints must correspond to the signing certificate that identifies the release app.

### Flutter Web Build

`flutter build web` compiles the app into static assets under `build/web`. Flutter reports tree-shaking and wasm dry-run output as part of modern web builds. Those messages are informational unless they include an actual failure.

## Verification Performed

Key passing checks:

```text
flutter analyze
flutter test
flutter build web --dart-define=APP_ENV=dev
flutter build apk --dart-define=APP_ENV=dev
npm --prefix functions run lint
npm --prefix functions run build
npm --prefix functions test
firebase deploy --only firestore:rules --project catch-dating-app-64e51 --dry-run
firebase deploy --only firestore:rules --project catch-dating-app-64e51
firebase emulators:exec --only firestore "npm --prefix functions run test:rules"
firebase functions:list --project catch-dating-app-64e51
firebase firestore:databases:list --project catch-dating-app-64e51
```

Known blocked checks:

```text
flutter build macos --dart-define=APP_ENV=dev
flutter build ios --simulator --no-codesign --dart-define=APP_ENV=dev
```

The blocks are Apple toolchain/signing/destination issues, not Dart analyzer failures.

## Study Path

1. Understand Firebase trust boundaries: Auth, Rules, Functions, App Check.
2. Read the safety plan and trace one flow: block user -> match hidden -> chat blocked -> sign-up denied.
3. Study one model end to end: `RunClub` Dart model -> Firestore document -> rules validation -> widget rendering.
4. Study one Function end to end: Razorpay order or sign-up flow -> trusted server data -> Firestore transaction.
5. Study provider overrides in tests: how Riverpod lets tests replace live dependencies.
6. Study Apple/Android signing separately from Flutter logic; it is an operating-system distribution problem, not a widget problem.

## Files To Keep Close

- `PROJECT_CONTEXT.md`
- `codex_audit/full_app_audit_tracker.md`
- `codex_audit/lib_feature_completeness_matrix.md`
- `codex_audit/firebase_console_audit.md`
- `codex_audit/safety_blocking_account_deletion_plan.md`
- `firestore.rules`
- `storage.rules`
- `firebase.json`
- `firestore.indexes.json`
- `functions/src/`
- `lib/routing/go_router.dart`
- `lib/core/app_config.dart`
- `lib/user_profile/domain/user_profile.dart`
- `lib/run_clubs/domain/run_club.dart`
- `functions/test/firestore.rules.test.cjs`

## New Codex Skill

Installed:

```text
/Users/suvratgarg/.codex/skills/teaching-changelog-email
```

Purpose:

- after a long coding session, create an educational changelog
- identify concepts worth teaching
- collect tracker markdown files
- prepare/send an email report
- preserve project and learning context for the next session

Validation caveat:

- The skill-creator validation helper could not run because the helper environment is missing `PyYAML`.
- The skill file and UI metadata were created manually and are structurally simple.

## Source Links

- Firebase App Check overview: https://firebase.google.com/docs/app-check
- Firebase App Check for Flutter: https://firebase.google.com/docs/app-check/flutter/default-providers
- Firebase App Check with Play Integrity: https://firebase.google.com/docs/app-check/android/play-integrity-provider
- Firebase App Check with App Attest: https://firebase.google.com/docs/app-check/ios/app-attest-provider
- Firebase App Check with reCAPTCHA Enterprise: https://firebase.google.com/docs/app-check/web/recaptcha-enterprise-provider
- Firebase Cloud Firestore locations: https://firebase.google.com/docs/firestore/locations
- Firebase Cloud Functions locations: https://firebase.google.com/docs/functions/locations
- Firebase Cloud Functions environment and secrets: https://firebase.google.com/docs/functions/config-env
- Firebase SHA fingerprints help: https://support.google.com/firebase/answer/9137403
- Firestore Security Rules emulator tests: https://firebase.google.com/docs/firestore/security/test-rules-emulator
- Firebase Rules unit testing package: https://firebase.google.com/docs/reference/emulator-suite/rules-unit-testing/rules-unit-testing
- Flutter web deployment: https://docs.flutter.dev/deployment/web
- Flutter Android deployment: https://docs.flutter.dev/deployment/android
- Flutter iOS deployment: https://docs.flutter.dev/deployment/ios
- Flutter macOS deployment: https://docs.flutter.dev/deployment/macos
- Riverpod documentation: https://riverpod.dev/
- Freezed package: https://pub.dev/packages/freezed
- share_plus package: https://pub.dev/packages/share_plus
